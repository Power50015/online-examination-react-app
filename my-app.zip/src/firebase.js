import { initializeApp } from "firebase/app";

export default initializeApp({
  apiKey: "AIzaSyDxVgQxtUwKdAIDGLb8ZmXtUKOpCl8xYEg",
  authDomain: "onlineexamination-b852e.firebaseapp.com",
  projectId: "onlineexamination-b852e",
  storageBucket: "onlineexamination-b852e.appspot.com",
  messagingSenderId: "693282493791",
  appId: "1:693282493791:web:6f6c58f00d35759a1a52ea",
});